import equality as E

data Box:
  | box(ref v)
end

f = lam(): "no-op" end

check "List where: block":
  [list: 1].push(0) is [list: 0, 1]

  [list: 1, 2, 3, 4, 5, 6].take(3) is [list: 1, 2, 3]

  [list: 1, 2, 3, 4, 5, 6].drop(3) is [list: 4, 5, 6]

  [list: 1, 2, 3].get(0) is 1
  [list: ].get(0) raises ""

  [list: 1, 2, 3].set(0, 5) is [list: 5, 2, 3]
  [list: ].set(0, 5) raises ""
end

check "get where: block":
  lists.get([list: 1, 2, 3], 0) is 1
  lists.get([list: ], 0) raises ""
end

check "set where: block":
  lists.set([list: 1, 2, 3], 0, 5) is [list: 5, 2, 3]
  lists.set([list: 1, 2, 3], 5, 5) raises ""
end

check "range where: block":
  lists.range(0,0) is [list: ]
  lists.range(0,1) is [list: 0]
  lists.range(-5,5) is [list: -5, -4, -3, -2, -1, 0, 1, 2, 3, 4]
  lists.range(0, 1/2) raises "Integer"
end

check "repeat where: block":
  lists.repeat(0, 10) is empty
  lists.repeat(3, -1) is [list: -1, -1, -1]
  lists.repeat(1, "foo") is link("foo", empty)
end

check "reverse where: block":
  lists.reverse([list: ]) is [list: ]
  lists.reverse([list: 1, 3]) is [list: 3, 1]
  lists.reverse([list: 1, 3, 2]) is [list: 2, 3, 1]
end

check "filter where: block":
  filter(lam(e): e > 5 end, [list: -1, 1]) is [list: ]
  filter(lam(e): e > 0 end, [list: -1, 1]) is [list: 1]
end

check "partition where: block":
  partition(lam(e): e > 0 end, [list: -1, 1]) is { is-true: [list: 1], is-false : [list: -1] }
  partition(lam(e): e > 5 end, [list: -1, 1]) is { is-true: [list: ], is-false : [list: -1, 1] }
  partition(lam(e): e < 5 end, [list: -1, 1]) is { is-true: [list: -1, 1], is-false : [list: ] }
end

check "find where: block":
  find(lam(elt): elt > 1 end, [list: 1, 2, 3]) is some(2)
  find(lam(elt): elt > 4 end, [list: 1, 2, 3]) is none
  find(lam(elt): true end, [list: "find-me", "miss-me"]) is some("find-me")
  find(lam(elt): true end, empty) is none
  find(lam(elt): false end, [list: "miss-me"]) is none
  find(lam(elt): false end, empty) is none
end

check "split-at where: block":
  one-four = link(1, link(2, link(3, link(4, empty))))

  split-at(0, one-four) is { prefix: empty, suffix: one-four }
  split-at(4, one-four) is { prefix: one-four, suffix: empty }
  split-at(2, one-four) is { prefix: link(1, link(2, empty)), suffix: link(3, link(4, empty)) }
  split-at(-1, one-four) raises "Invalid index"
  split-at(1.35, one-four) raises "Invalid index"
  split-at(5, one-four) raises "Index too large"
end

check "any where: block":
  any(lam(n): n > 1 end, [list: 1, 2, 3]) is true
  any(lam(n): n > 3 end, [list: 1, 2, 3]) is false
  any(lam(x): true  end, empty) is false
  any(lam(x): false end, empty) is false
end

check "all where: block":
  lists.all(lam(n): n > 1 end, [list: 1, 2, 3]) is false
  lists.all(lam(n): n <= 3 end, [list: 1, 2, 3]) is true
  lists.all(lam(x): true  end, empty) is true
  lists.all(lam(x): false end, empty) is true
end

check "all2 where: block":
  lists.all2(lam(n, m): false end, [list: 1, 2, 3], empty) is true
  lists.all2(lam(n, m): true  end, [list: 1, 2, 3], empty) is true
  lists.all2(lam(n, m): n > m end,        [list: 1, 2, 3], [list: 0, 1, 2]) is true
  lists.all2(lam(n, m): (n + m) == 3 end, [list: 1, 2, 3], [list: 2, 1, 0]) is true
  lists.all2(lam(n, m): n < m end,        [list: 1, 2, 3], [list: 0, 1, 2]) is false
  lists.all2(lam(_, _): true  end, empty, empty) is true
  lists.all2(lam(_, _): false end, empty, empty) is true
end

check "map where: block":
  map(lam(_): raise("shipwrecked!") end, [list: ]) is [list: ]
  map(lam(_): 2 end, [list: 1, 2, 3, 4]) is [list: 2, 2, 2, 2]
  map(lam(x): x + 1 end, [list: 1, 2, 3, 4]) is [list: 2, 3, 4, 5]
end

check "map2 where: block":
  map2(lam(_, _): raise("shipwrecked!") end, [list: ], [list: ]) is [list: ]
  map2(lam(x, y): x or y end, [list: true, false], [list: false, false]) is [list: true, false]
end

check "map_n where: block":
  map_n(lam(n, e): n end, 0, [list: "captain", "first mate"]) is [list: 0, 1]
end

check "fold where: block":
  fold(lam(acc, cur): acc end, 1, [list: 1, 2, 3, 4]) is 1
  fold(lam(acc, cur): cur end, 1, [list: 1, 2, 3, 4]) is 4
  fold(lam(acc, cur): acc + cur end, 0, [list: 1, 2, 3, 4]) is 10
  fold(lam(lst, elt): link(elt, lst) end, empty, [list: 1, 2, 3]) is [list: 3, 2, 1]
end

check "foldr":
  lists.foldr(lam(lst, elt): link(elt, lst) end, empty, [list: 1, 2, 3]) is [list: 1, 2, 3]
end

check "fold2 where: block":
  fold2(lam(x, y, z): x - y - z end, 6, [list: 1, 1, 1], [list: 1, 1, 1]) is 0
end

check "fold_n where: block":
  lists.fold_n(lam(n, acc, _): n * acc end, 1, 1, [list: "a", "b", "c", "d"]) is 1 * 2 * 3 * 4
  lists.fold_n(lam(n, acc, cur):
                  tostring(n) + " " + cur + ", " + acc
               end,
               95, "and so forth...", repeat(5, "jugs o' grog in the hold"))
    is "99 jugs o' grog in the hold, 98 jugs o' grog in the hold, "
    + "97 jugs o' grog in the hold, 96 jugs o' grog in the hold, "
    + "95 jugs o' grog in the hold, and so forth..."
  lists.fold_n(lam(n, acc, cur): ((num-modulo(n, 2) == 0) or cur) and acc end,
               0, true, [list: false, true, false])
    is true
end

check "member":

  # This is the old version that just uses == internally
  traditional-member = lam(l, elt): l.member(elt) end

  l = [list: 1, f, 3]

  traditional-member(l, 1) is true
  traditional-member(l, 3) is true
  traditional-member(l, f) raises "function"
  traditional-member(l, 5) is false

  lists.member3(l, 1) is E.Equal
  lists.member3(l, 3) is E.Equal
  lists.member3(l, f) satisfies E.is-Unknown
  lists.member3(l, 5) satisfies E.is-NotEqual

  lists.member(l, 1) is true
  lists.member(l, 3) is true
  lists.member(l, f) raises "function"
  lists.member(l, 5) is false

  b1 = box(5)
  b2 = box(5)
  l1 = [list: 1, b1]

  lists.member-now(l1, b1) is true
  lists.member-now(l1, b2) is true
  lists.member-now3(l1, b1) is E.Equal
  lists.member-now3(l1, b2) is E.Equal

  lists.member-always(l1, b1) is true
  lists.member-always(l1, b2) is false
  lists.member-always3(l1, b1) is E.Equal
  lists.member-always3(l1, b2) satisfies E.is-NotEqual

  lists.member-identical(l1, b1) is true
  lists.member-identical(l1, b2) is false
  lists.member-identical3(l1, b1) is E.Equal
  lists.member-identical3(l1, b2) satisfies E.is-NotEqual

  b1!{v: 10}

  lists.member-now(l1, b1) is true
  lists.member-now(l1, b2) is false
  lists.member-now3(l1, b1) is E.Equal
  lists.member-now3(l1, b2) satisfies E.is-NotEqual

end

check "shuffle":
  l = [list: 1, 2, 3, 4]

  num-random-seed(0)
  l-mixed = lists.shuffle(l)
  sets.list-to-set(l-mixed) is sets.list-to-set(l)
  l-mixed.length() is l.length()

  num-random-seed(0)
  l-mixed2 = lists.shuffle(l)
  l-mixed2 is l-mixed

  two-elts = [list: 1, 2]
  {saw-same; saw-different} =
    for fold({saw-same; saw-different} from {false; false}, i from range(0, 100)):
      same = (lists.shuffle(two-elts) == two-elts)
      {
        saw-same or same;
        saw-different or not(same)
      }
    end
  saw-same is true
  saw-different is true
end

check "string helper":
  lists.join-str([list: "a", "b"], ",") is "a,b"
  lists.join-str([list: "", "", ""], "") is ""
  lists.join-str([list: "", "a", ""], ",") is ",a,"
  lists.join-str([list:], ",") is ""
  lists.join-str([list: "a"], ",") is "a"
  lists.join-str([list: "a", "b", "c", "d", "e"], "  ") is "a  b  c  d  e"

  lists.join-str-last([list: 1, "2", 3], "+", "-") is "1+2-3"
  lists.join-str-last([list: ], "+", "-") is ""
  lists.join-str-last([list: 1], "+", "-") is "1"
  lists.join-str-last([list: 1, 2], "+", "-") is "1-2"
  lists.join-str-last([list: 1, 2, 3, 4], "+", "-") is "1+2+3-4"
end

check "sort as a function":
  lists.sort([list: 1, 5, 6, 2, 3]) is [list: 1, 2, 3, 5, 6]

  lists.sort([list: "dog", "Dog", "DOG"]) is [list: "DOG", "Dog", "dog"]

  lists.sort-by([list:
      { name: "Bob", age: 22 },
      { name: "Amy", age: 5 },
      { name: "Bob", age: 17 },
      { name: "Joan", age: 43 },
      { name: "Alex", age: 3 }],
    lam(p1, p2): p1.age < p2.age end,
    lam(p1, p2): p1.age == p2.age end)
    is
    [list:
      { name: "Alex", age: 3 },
      { name: "Amy", age: 5 },
      { name: "Bob", age: 17 },
      { name: "Bob", age: 22 },
      { name: "Joan", age: 43 }]
end

check "stable sort":
  #|
     Builds a collection of triples {0;0;_}, {0;1;_}, ... {0;n;_}, {1;0;_}, {1;1;_}...
     The first two components are a Cartesian product of [0,250)x[0;4).
     The third component is simply a sequential number, [0, TOTAL).

     This list is *actually* constructed in the order
          {249;0;_}, {249;1;_}, ... {248;0,_}, {248;1;_}, ... {0;0;_}...,
     such that it is in *decreasing* order on the first component of each tuple, and
     *increasing* order on the other two components.

     The idea is to sort the list by only comparing the first components, both stably and unstably.
     The *third* component of each tuple helps to tell apart the original items, despite the comparison
     being agnostic to them.
  |#
  fun build-pairs(m, n):
    raw-array-to-list(raw-array-build(lam(i):
          raw-array-to-list(raw-array-build(lam(j): {i; j; (i * (m + 1)) + j} end, n))
        end, m))
      .foldl(_.append(_), empty)
  end
  
  TOTAL = 1000
  GROUPS = 250
  
  pairs = (build-pairs(GROUPS, TOTAL / GROUPS))
  
  fun pair-le(p1, p2):
    (p1.{0} < p2.{0})
  end
  
  fun pair-eq(p1, p2): 
    p1.{0} == p2.{0}
  end
  
  stable-sorted = pairs.stable-sort-by(pair-le, pair-eq)
  unstable-sorted = pairs.sort-by(pair-le, pair-eq)
  unstable-sorted is-not stable-sorted
  for each(i from range(0, GROUPS)):
    stable-sorted.filter({(p): p.{0} == i}) is pairs.filter({(p): p.{0} == i})
  end
end

check "distinct":
  lists.distinct([list: ~1, ~1]) is-roughly [list: ~1, ~1]
  lists.distinct([list: ~1, ~1, 1]) is-roughly [list: ~1, ~1, 1]
  lists.distinct([list: ~1, ~1, 1, 1]) is-roughly [list: ~1, ~1, 1]
  lists.distinct([list: ~1, ~2, ~3]) is-roughly [list: ~1, ~2, ~3]
end

check "more utility functions":
  lists.last([list: 1]) is 1
  lists.last([list: 1, 2, 3, 4, 5, 6, 7]) is 7

  lists.append([list: 1, 2, 3], [list: 4, 5, 6]) is [list: 1, 2, 3, 4, 5, 6]

  lists.push(empty, 1) is link(1, empty)
end

check "build":
  lists.build-list(lam(x): x * 2 end, 6) is [list: 0, 2, 4, 6, 8, 10]
  lists.build-list(lam(x): to-repr(x) end, 2) is [list: "0", "1"]
  lists.build-list(lam(x): to-repr(x) end, 0) is empty
  lists.build-list(lam(x): x * 2 end, -1) raises "NumNonNegative"
  lists.build-list("not-a-function", -1) raises "Function"
end
